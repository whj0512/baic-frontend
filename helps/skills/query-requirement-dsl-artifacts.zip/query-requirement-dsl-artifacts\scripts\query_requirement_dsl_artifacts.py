#!/usr/bin/env python3
"""Return requirement-linked DSL artifacts as a deduplicated JSON tool result."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Sequence


PROTOCOL_VERSION = "1.0"

EXIT_SUCCESS = 0
EXIT_INPUT_OR_PATH = 2
EXIT_READ_OR_JSON = 3
EXIT_SCHEMA_OR_CONTRACT = 4

TYPE_ENVIRONMENT = "environment"
TYPE_EXTERNAL_SCENARIO = "external-scenario"
TYPE_STATECHART = "statechart"
DSL_TYPES = (
    TYPE_ENVIRONMENT,
    TYPE_EXTERNAL_SCENARIO,
    TYPE_STATECHART,
)

POWERSHELL_FILE_RE = re.compile(
    r"(?:^|;\s*)file\s*=\s*([^;}]+)",
    flags=re.IGNORECASE,
)
LEADING_DSL_PATH_RE = re.compile(
    r"^\s*(.+?\.dsl)(?=::|#|$)",
    flags=re.IGNORECASE,
)


def configure_stdout() -> None:
    reconfigure = getattr(sys.stdout, "reconfigure", None)
    if reconfigure is not None:
        reconfigure(encoding="utf-8", errors="strict", newline="")


class QueryError(Exception):
    def __init__(self, code: str, message: str, exit_code: int) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.exit_code = exit_code


class ProtocolArgumentParser(argparse.ArgumentParser):
    """Raise argument errors so stdout always remains valid protocol JSON."""

    def error(self, message: str) -> None:
        raise QueryError(
            "INVALID_INPUT",
            f"参数无效: {message}",
            EXIT_INPUT_OR_PATH,
        )


@dataclass(frozen=True)
class Artifact:
    artifact_id: str
    dsl_type: str
    content: str


@dataclass(frozen=True)
class RequirementResult:
    requirement_id: str
    name: str
    description: str
    artifact_ids: tuple[str, ...]
    is_orphan: bool


@dataclass(frozen=True)
class QueryResult:
    feature_count: int
    requirements: tuple[RequirementResult, ...]
    artifacts: tuple[Artifact, ...]
    source_requirement_count: int
    unmapped_source_requirement_count: int

    @property
    def relationship_count(self) -> int:
        return sum(len(item.artifact_ids) for item in self.requirements)

    @property
    def empty_artifact_requirement_count(self) -> int:
        return sum(not item.artifact_ids for item in self.requirements)

    @property
    def missing_name_count(self) -> int:
        return sum(not item.name for item in self.requirements)

    @property
    def missing_description_count(self) -> int:
        return sum(not item.description for item in self.requirements)

    @property
    def metadata_missing_count(self) -> int:
        return sum(
            not item.name or not item.description for item in self.requirements
        )

    @property
    def orphan_requirement_count(self) -> int:
        return sum(item.is_orphan for item in self.requirements)

    def type_counts(self) -> dict[str, int]:
        counts = {dsl_type: 0 for dsl_type in DSL_TYPES}
        for artifact in self.artifacts:
            counts[artifact.dsl_type] += 1
        return counts


def build_parser() -> argparse.ArgumentParser:
    parser = ProtocolArgumentParser(
        description=(
            "Read direct-child feature requirement maps and return one "
            "deduplicated JSON tool result."
        )
    )
    parser.add_argument("--project-root", required=True)
    return parser


def render_envelope(
    *,
    status: str,
    summary: dict[str, int] | None,
    requirements: dict[str, dict[str, Any]],
    artifacts: dict[str, dict[str, str]],
    warnings: list[dict[str, str]],
    error: dict[str, str] | None,
) -> str:
    envelope = {
        "protocol_version": PROTOCOL_VERSION,
        "status": status,
        "summary": summary,
        "requirements": requirements,
        "artifacts": artifacts,
        "warnings": warnings,
        "error": error,
    }
    return json.dumps(
        envelope,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def render_error(code: str, message: str) -> str:
    return render_envelope(
        status="error",
        summary=None,
        requirements={},
        artifacts={},
        warnings=[],
        error={"code": code, "message": message},
    )


def read_json(path: Path, *, missing_code: str) -> Any:
    if not path.exists():
        raise QueryError(
            missing_code,
            f"缺少必需文件: {path}",
            EXIT_INPUT_OR_PATH,
        )
    if not path.is_file():
        raise QueryError(
            "JSON_READ_FAILED",
            f"JSON 路径不是普通文件: {path}",
            EXIT_READ_OR_JSON,
        )
    try:
        raw = path.read_bytes().decode("utf-8-sig")
    except (OSError, UnicodeError) as exc:
        raise QueryError(
            "JSON_READ_FAILED",
            f"无法读取 {path}: {exc}",
            EXIT_READ_OR_JSON,
        ) from exc
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise QueryError(
            "INVALID_JSON",
            f"{path} 不是合法 JSON（第 {exc.lineno} 行，第 {exc.colno} 列）",
            EXIT_READ_OR_JSON,
        ) from exc


def require_object(data: Any, path: Path) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise QueryError(
            "INVALID_JSON_SCHEMA",
            f"{path} 根节点必须是 JSON 对象",
            EXIT_SCHEMA_OR_CONTRACT,
        )
    return data


def parse_requirements(
    data: Any,
    path: Path,
    global_source_ids: set[str],
) -> tuple[dict[str, tuple[str, str]], list[str]]:
    root = require_object(data, path)
    raw_items = root.get("requirements")
    if not isinstance(raw_items, list):
        raise QueryError(
            "INVALID_REQUIREMENTS_SCHEMA",
            f"{path} 缺少 requirements 数组",
            EXIT_SCHEMA_OR_CONTRACT,
        )

    by_id: dict[str, tuple[str, str]] = {}
    order: list[str] = []
    for index, item in enumerate(raw_items):
        if not isinstance(item, dict):
            raise QueryError(
                "INVALID_REQUIREMENTS_SCHEMA",
                f"{path}: requirements[{index}] 必须是对象",
                EXIT_SCHEMA_OR_CONTRACT,
            )
        requirement_id = item.get("requirement_id")
        if not isinstance(requirement_id, str) or not requirement_id.strip():
            raise QueryError(
                "INVALID_REQUIREMENTS_SCHEMA",
                f"{path}: requirements[{index}].requirement_id 必须是非空字符串",
                EXIT_SCHEMA_OR_CONTRACT,
            )
        if requirement_id in by_id or requirement_id in global_source_ids:
            raise QueryError(
                "DUPLICATE_REQUIREMENT_ID",
                f"requirements.json 中存在重复 requirement_id: {requirement_id}",
                EXIT_SCHEMA_OR_CONTRACT,
            )

        name = item.get("name", "")
        description = item.get("description", "")
        if name is None:
            name = ""
        if description is None:
            description = ""
        if not isinstance(name, str):
            raise QueryError(
                "INVALID_REQUIREMENT_METADATA",
                f"{requirement_id}.name 必须是字符串、null 或缺失",
                EXIT_SCHEMA_OR_CONTRACT,
            )
        if not isinstance(description, str):
            raise QueryError(
                "INVALID_REQUIREMENT_METADATA",
                f"{requirement_id}.description 必须是字符串、null 或缺失",
                EXIT_SCHEMA_OR_CONTRACT,
            )

        by_id[requirement_id] = (name, description)
        order.append(requirement_id)
        global_source_ids.add(requirement_id)
    return by_id, order


def iter_map_entries(
    data: Any,
    path: Path,
) -> Iterable[tuple[str, list[Any], bool]]:
    root = require_object(data, path)
    recognized = False
    schemas = (
        ("requirement_dsl_map", "dsl_references", False),
        ("coverage", "artifacts", False),
        ("dsl_map", "artifacts", False),
        ("orphan_dsl_references", "dsl_references", True),
    )
    for collection_name, artifact_field, orphan in schemas:
        if collection_name not in root:
            continue
        recognized = True
        collection = root[collection_name]
        if not isinstance(collection, list):
            raise QueryError(
                "INVALID_MAP_SCHEMA",
                f"{path}: {collection_name} 必须是数组",
                EXIT_SCHEMA_OR_CONTRACT,
            )
        for index, item in enumerate(collection):
            if not isinstance(item, dict):
                raise QueryError(
                    "INVALID_MAP_SCHEMA",
                    f"{path}: {collection_name}[{index}] 必须是对象",
                    EXIT_SCHEMA_OR_CONTRACT,
                )
            requirement_id = item.get("requirement_id")
            if not isinstance(requirement_id, str) or not requirement_id.strip():
                raise QueryError(
                    "INVALID_MAP_SCHEMA",
                    (
                        f"{path}: {collection_name}[{index}].requirement_id "
                        "必须是非空字符串"
                    ),
                    EXIT_SCHEMA_OR_CONTRACT,
                )
            raw_artifacts = item.get(artifact_field, [])
            if raw_artifacts is None:
                raw_artifacts = []
            if not isinstance(raw_artifacts, list):
                raise QueryError(
                    "INVALID_MAP_SCHEMA",
                    f"{path}: {requirement_id}.{artifact_field} 必须是数组",
                    EXIT_SCHEMA_OR_CONTRACT,
                )
            yield requirement_id, raw_artifacts, orphan

    if not recognized:
        raise QueryError(
            "UNKNOWN_MAP_SCHEMA",
            (
                f"{path} 未包含 requirement_dsl_map、coverage、dsl_map "
                "或 orphan_dsl_references"
            ),
            EXIT_SCHEMA_OR_CONTRACT,
        )


def extract_artifact_path(raw_artifact: Any, context: str) -> str:
    def normalize(raw_path: str) -> str:
        normalized = raw_path.strip()
        if (
            len(normalized) >= 2
            and normalized[0] == normalized[-1]
            and normalized[0] in {'"', "'"}
        ):
            normalized = normalized[1:-1].strip()
        return normalized.replace("\\", "/")

    if isinstance(raw_artifact, dict):
        raw_path = raw_artifact.get("file")
        if not isinstance(raw_path, str) or not raw_path.strip():
            raise QueryError(
                "INVALID_ARTIFACT_REFERENCE",
                f"{context}: 结构化 artifact 缺少非空 file 字段",
                EXIT_SCHEMA_OR_CONTRACT,
            )
        return normalize(raw_path)

    if not isinstance(raw_artifact, str) or not raw_artifact.strip():
        raise QueryError(
            "INVALID_ARTIFACT_REFERENCE",
            f"{context}: artifact 必须是非空字符串或带 file 的对象",
            EXIT_SCHEMA_OR_CONTRACT,
        )

    text = raw_artifact.strip()
    powershell_match = POWERSHELL_FILE_RE.search(text)
    if powershell_match:
        return normalize(powershell_match.group(1))

    path_match = LEADING_DSL_PATH_RE.match(text)
    if path_match:
        return normalize(path_match.group(1))

    raise QueryError(
        "INVALID_ARTIFACT_REFERENCE",
        f"{context}: 无法从 artifact 提取 .dsl 文件路径: {text}",
        EXIT_SCHEMA_OR_CONTRACT,
    )


def classify_artifact(relative_path: str) -> str | None:
    pure = PurePosixPath(relative_path)
    parts = pure.parts
    if not parts:
        raise QueryError(
            "INVALID_ARTIFACT_PATH",
            "artifact 路径为空",
            EXIT_SCHEMA_OR_CONTRACT,
        )
    if (
        pure.is_absolute()
        or ".." in parts
        or "." in parts
        or re.match(r"^[A-Za-z]:", parts[0])
    ):
        raise QueryError(
            "ARTIFACT_PATH_OUTSIDE_FEATURE",
            f"artifact 路径必须是功能目录内的相对路径: {relative_path}",
            EXIT_SCHEMA_OR_CONTRACT,
        )

    first = parts[0].casefold()
    if first == "dialogmaps":
        return None
    if len(parts) == 1 and parts[0].casefold() == "environment.dsl":
        return TYPE_ENVIRONMENT
    if (
        len(parts) == 2
        and first == "externalscenarios"
        and parts[1].casefold().endswith(".dsl")
    ):
        return TYPE_EXTERNAL_SCENARIO
    if (
        len(parts) == 2
        and first == "statecharts"
        and parts[1].casefold().endswith(".dsl")
    ):
        return TYPE_STATECHART
    raise QueryError(
        "UNKNOWN_DSL_TYPE",
        f"不支持的 DSL artifact 路径: {relative_path}",
        EXIT_SCHEMA_OR_CONTRACT,
    )


def resolve_artifact(
    feature_root: Path,
    project_root: Path,
    relative_path: str,
    dsl_type: str,
) -> tuple[Path, str]:
    pure = PurePosixPath(relative_path)
    candidate = feature_root.joinpath(*pure.parts)
    try:
        resolved = candidate.resolve(strict=False)
        feature_resolved = feature_root.resolve(strict=True)
        project_resolved = project_root.resolve(strict=True)
    except OSError as exc:
        raise QueryError(
            "INVALID_ARTIFACT_PATH",
            f"无法规范化 artifact 路径 {relative_path}: {exc}",
            EXIT_SCHEMA_OR_CONTRACT,
        ) from exc

    try:
        feature_common = os.path.commonpath(
            (str(feature_resolved), str(resolved))
        )
        project_common = os.path.commonpath(
            (str(project_resolved), str(resolved))
        )
    except ValueError as exc:
        raise QueryError(
            "ARTIFACT_PATH_OUTSIDE_FEATURE",
            f"artifact 路径越界: {relative_path}",
            EXIT_SCHEMA_OR_CONTRACT,
        ) from exc
    if os.path.normcase(feature_common) != os.path.normcase(str(feature_resolved)):
        raise QueryError(
            "ARTIFACT_PATH_OUTSIDE_FEATURE",
            f"artifact 路径越出功能目录: {relative_path}",
            EXIT_SCHEMA_OR_CONTRACT,
        )
    if os.path.normcase(project_common) != os.path.normcase(str(project_resolved)):
        raise QueryError(
            "ARTIFACT_PATH_OUTSIDE_FEATURE",
            f"artifact 路径越出项目根目录: {relative_path}",
            EXIT_SCHEMA_OR_CONTRACT,
        )
    if not resolved.exists() or not resolved.is_file():
        raise QueryError(
            "DSL_NOT_FOUND",
            f"映射引用的 DSL 文件不存在: {resolved}",
            EXIT_INPUT_OR_PATH,
        )

    project_relative = resolved.relative_to(project_resolved).as_posix()
    return resolved, project_relative


def read_dsl(path: Path) -> str:
    try:
        return path.read_bytes().decode("utf-8-sig")
    except (OSError, UnicodeError) as exc:
        raise QueryError(
            "DSL_READ_FAILED",
            f"无法读取 DSL 文件 {path}: {exc}",
            EXIT_READ_OR_JSON,
        ) from exc


def build_query_result(project_root: Path) -> QueryResult:
    feature_dirs = sorted(
        (
            child
            for child in project_root.iterdir()
            if child.is_dir() and (child / "requirement_dsl_map.json").is_file()
        ),
        key=lambda path: path.name.casefold(),
    )
    if not feature_dirs:
        raise QueryError(
            "DSL_MAP_NOT_FOUND",
            "项目根目录的直接子目录中未找到 requirement_dsl_map.json",
            EXIT_INPUT_OR_PATH,
        )

    requirement_results: list[RequirementResult] = []
    artifact_results: dict[str, Artifact] = {}
    artifact_id_by_resolved_path: dict[str, str] = {}
    global_map_ids: set[str] = set()
    global_source_ids: set[str] = set()
    source_requirement_count = 0
    unmapped_source_requirement_count = 0

    for feature_root in feature_dirs:
        requirements_path = feature_root / "requirements.json"
        map_path = feature_root / "requirement_dsl_map.json"
        requirements_data = read_json(
            requirements_path,
            missing_code="REQUIREMENTS_NOT_FOUND",
        )
        map_data = read_json(map_path, missing_code="DSL_MAP_NOT_FOUND")
        requirements_by_id, source_order = parse_requirements(
            requirements_data,
            requirements_path,
            global_source_ids,
        )
        source_requirement_count += len(requirements_by_id)

        feature_map_ids: set[str] = set()
        for requirement_id, raw_artifacts, explicitly_orphan in iter_map_entries(
            map_data,
            map_path,
        ):
            if requirement_id in feature_map_ids or requirement_id in global_map_ids:
                raise QueryError(
                    "DUPLICATE_REQUIREMENT_ID",
                    (
                        "requirement_dsl_map.json 中存在重复 requirement_id: "
                        f"{requirement_id}"
                    ),
                    EXIT_SCHEMA_OR_CONTRACT,
                )
            feature_map_ids.add(requirement_id)
            global_map_ids.add(requirement_id)

            metadata = requirements_by_id.get(requirement_id)
            is_orphan = explicitly_orphan or metadata is None
            name, description = metadata if metadata is not None else ("", "")

            requirement_artifact_ids: list[str] = []
            seen_requirement_paths: set[str] = set()
            for artifact_index, raw_artifact in enumerate(raw_artifacts):
                context = f"{map_path}: {requirement_id}.artifacts[{artifact_index}]"
                relative_path = extract_artifact_path(raw_artifact, context)
                dsl_type = classify_artifact(relative_path)
                if dsl_type is None:
                    continue

                resolved, project_relative = resolve_artifact(
                    feature_root,
                    project_root,
                    relative_path,
                    dsl_type,
                )
                resolved_key = os.path.normcase(str(resolved))
                if resolved_key in seen_requirement_paths:
                    continue
                seen_requirement_paths.add(resolved_key)

                artifact_id = artifact_id_by_resolved_path.get(resolved_key)
                if artifact_id is None:
                    artifact_id = project_relative
                    artifact_id_by_resolved_path[resolved_key] = artifact_id
                    artifact_results[artifact_id] = Artifact(
                        artifact_id=artifact_id,
                        dsl_type=dsl_type,
                        content=read_dsl(resolved),
                    )
                else:
                    existing = artifact_results[artifact_id]
                    if existing.dsl_type != dsl_type:
                        raise QueryError(
                            "ARTIFACT_TYPE_CONFLICT",
                            f"同一 DSL 文件被识别为不同类型: {project_relative}",
                            EXIT_SCHEMA_OR_CONTRACT,
                        )
                requirement_artifact_ids.append(artifact_id)

            requirement_results.append(
                RequirementResult(
                    requirement_id=requirement_id,
                    name=name,
                    description=description,
                    artifact_ids=tuple(requirement_artifact_ids),
                    is_orphan=is_orphan,
                )
            )

        unmapped_source_requirement_count += sum(
            requirement_id not in feature_map_ids for requirement_id in source_order
        )

    return QueryResult(
        feature_count=len(feature_dirs),
        requirements=tuple(requirement_results),
        artifacts=tuple(artifact_results.values()),
        source_requirement_count=source_requirement_count,
        unmapped_source_requirement_count=unmapped_source_requirement_count,
    )


def render_success(result: QueryResult) -> str:
    type_counts = result.type_counts()
    summary = {
        "feature_count": result.feature_count,
        "requirement_count": len(result.requirements),
        "source_requirement_count": result.source_requirement_count,
        "artifact_count": len(result.artifacts),
        "relationship_count": result.relationship_count,
        "environment_count": type_counts[TYPE_ENVIRONMENT],
        "external_scenario_count": type_counts[TYPE_EXTERNAL_SCENARIO],
        "statechart_count": type_counts[TYPE_STATECHART],
        "empty_artifact_requirement_count": (
            result.empty_artifact_requirement_count
        ),
        "missing_name_count": result.missing_name_count,
        "missing_description_count": result.missing_description_count,
        "metadata_missing_count": result.metadata_missing_count,
        "orphan_requirement_count": result.orphan_requirement_count,
        "unmapped_source_requirement_count": (
            result.unmapped_source_requirement_count
        ),
    }
    requirements = {
        item.requirement_id: {
            "name": item.name,
            "description": item.description,
            "artifacts": list(item.artifact_ids),
        }
        for item in result.requirements
    }
    artifacts = {
        item.artifact_id: {
            "type": item.dsl_type,
            "content": item.content,
        }
        for item in result.artifacts
    }
    warnings = [
        {
            "code": "REQUIREMENT_METADATA_NOT_FOUND",
            "requirement_id": item.requirement_id,
        }
        for item in result.requirements
        if item.is_orphan
    ]
    return render_envelope(
        status="success",
        summary=summary,
        requirements=requirements,
        artifacts=artifacts,
        warnings=warnings,
        error=None,
    )


def normalize_project_root(raw_project_root: str) -> Path:
    try:
        candidate = Path(raw_project_root).expanduser()
    except (TypeError, ValueError, OSError) as exc:
        raise QueryError(
            "INVALID_INPUT",
            f"项目根目录路径无效: {exc}",
            EXIT_INPUT_OR_PATH,
        ) from exc
    if not candidate.is_absolute():
        raise QueryError(
            "INVALID_INPUT",
            "project_root 必须是绝对路径",
            EXIT_INPUT_OR_PATH,
        )
    try:
        resolved = candidate.resolve(strict=False)
    except OSError as exc:
        raise QueryError(
            "INVALID_INPUT",
            f"无法规范化项目根目录: {exc}",
            EXIT_INPUT_OR_PATH,
        ) from exc
    if not resolved.exists():
        raise QueryError(
            "ROOT_NOT_FOUND",
            f"项目根目录不存在: {resolved}",
            EXIT_INPUT_OR_PATH,
        )
    if not resolved.is_dir():
        raise QueryError(
            "ROOT_NOT_DIRECTORY",
            f"project_root 不是目录: {resolved}",
            EXIT_INPUT_OR_PATH,
        )
    return resolved


def run(argv: Sequence[str] | None = None) -> int:
    configure_stdout()
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        project_root = normalize_project_root(args.project_root)
        result = build_query_result(project_root)
        output = render_success(result)
    except QueryError as exc:
        sys.stdout.write(render_error(exc.code, exc.message) + "\n")
        return exc.exit_code
    except OSError as exc:
        sys.stdout.write(
            render_error(
                "PROJECT_READ_FAILED",
                f"无法读取项目目录: {exc}",
            )
            + "\n"
        )
        return EXIT_READ_OR_JSON

    sys.stdout.write(output + "\n")
    return EXIT_SUCCESS


def main() -> None:
    raise SystemExit(run())


if __name__ == "__main__":
    main()
