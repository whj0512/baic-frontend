import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = SKILL_ROOT / "scripts" / "query_requirement_dsl_artifacts.py"


class QueryRequirementDslArtifactsTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(
            prefix="query-requirement-dsl-artifacts-test-",
            dir=SKILL_ROOT.parent,
        )
        self.addCleanup(self.temp_dir.cleanup)
        self.project_root = Path(self.temp_dir.name) / "项目"
        self.project_root.mkdir()

    def write_json(self, path, data):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def write_dsl(self, feature, relative_path, content):
        path = feature / Path(relative_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content.encode("utf-8"))
        return path

    def create_feature(self, name, requirements, mapping):
        feature = self.project_root / name
        feature.mkdir()
        self.write_json(feature / "requirements.json", {"requirements": requirements})
        self.write_json(feature / "requirement_dsl_map.json", mapping)
        return feature

    def run_cli(self, project_root=None):
        root = project_root if project_root is not None else self.project_root
        return subprocess.run(
            [
                sys.executable,
                str(SCRIPT),
                "--project-root",
                str(root),
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            check=False,
        )

    def parse_protocol(self, completed):
        self.assertEqual("", completed.stderr)
        self.assertTrue(completed.stdout.startswith("{"))
        self.assertTrue(completed.stdout.endswith("}\n"))
        self.assertNotIn("```", completed.stdout)
        return json.loads(completed.stdout)

    def assert_protocol_error(self, completed, error_code):
        self.assertNotEqual(0, completed.returncode)
        payload = self.parse_protocol(completed)
        self.assertEqual("error", payload["status"])
        self.assertIsNone(payload["summary"])
        self.assertEqual({}, payload["requirements"])
        self.assertEqual({}, payload["artifacts"])
        self.assertEqual(error_code, payload["error"]["code"])

    def test_all_mapping_shapes_are_deduplicated_json(self):
        special_name = '名称 "A" \\ B\n第二行\t末尾'
        special_description = '描述包含 "引号"、\\路径\n下一行\t完成'

        legacy = self.create_feature(
            "1旧格式",
            [
                {
                    "requirement_id": "REQ_LEGACY",
                    "name": special_name,
                    "description": special_description,
                    "source_text": "不得作为回退来源",
                },
                {
                    "requirement_id": "REQ_EMPTY",
                    "source_text": "只有原文",
                },
            ],
            {
                "requirement_dsl_map": [
                    {
                        "requirement_id": "REQ_LEGACY",
                        "dsl_references": [
                            "Environment.dsl::Interaction 输入",
                            "ExternalScenarios/共享场景.dsl",
                            "ExternalScenarios/共享场景.dsl#duplicate",
                            "DialogMaps/忽略.dsl",
                        ],
                    },
                    {
                        "requirement_id": "REQ_EMPTY",
                        "dsl_references": ["DialogMaps/仅界面.dsl"],
                    },
                ],
                "orphan_dsl_references": [
                    {
                        "requirement_id": "REQ_ORPHAN",
                        "dsl_references": [
                            "Statecharts\\孤立状态机.dsl#State A"
                        ],
                    }
                ],
            },
        )
        environment_content = "Environment {\r\n  Machine 示例模块;\r\n}\r\n"
        legacy_scenario_content = "Scenario 共享场景 {\n  Interaction 输入;\n}\n"
        orphan_statechart_content = (
            "Statechart 孤立状态机 {\n"
            "  Start 开始;\n"
            "  State 完成 { };\n"
            "}\n"
        )
        self.write_dsl(legacy, "Environment.dsl", environment_content)
        self.write_dsl(
            legacy,
            "ExternalScenarios/共享场景.dsl",
            legacy_scenario_content,
        )
        self.write_dsl(
            legacy,
            "Statecharts/孤立状态机.dsl",
            orphan_statechart_content,
        )

        coverage = self.create_feature(
            "2覆盖格式",
            [{"requirement_id": "REQ_COVERAGE", "name": None, "description": ""}],
            {
                "coverage": [
                    {
                        "requirement_id": "REQ_COVERAGE",
                        "artifacts": [
                            "ExternalScenarios/共享场景.dsl#full scenario",
                            {
                                "type": "Statechart",
                                "file": "Statecharts/覆盖状态机.dsl",
                                "element": "State 完成",
                            },
                        ],
                    }
                ]
            },
        )
        coverage_scenario_content = (
            "Scenario 覆盖场景 {\n  Interaction 执行动作;\n}\n"
        )
        coverage_statechart_content = "Statechart 覆盖状态机 {\n  Start 开始;\n}\n"
        self.write_dsl(
            coverage,
            "ExternalScenarios/共享场景.dsl",
            coverage_scenario_content,
        )
        self.write_dsl(
            coverage,
            "Statecharts/覆盖状态机.dsl",
            coverage_statechart_content,
        )

        dsl_map = self.create_feature(
            "3对象字符串格式",
            [
                {
                    "requirement_id": "REQ_OBJECT_STRING",
                    "name": "对象字符串",
                    "description": "解析 file 字段",
                }
            ],
            {
                "dsl_map": [
                    {
                        "requirement_id": "REQ_OBJECT_STRING",
                        "artifacts": [
                            (
                                "@{type=Scenario; "
                                "file=ExternalScenarios/对象字符串.dsl; "
                                "element=Scenario 对象字符串}"
                            )
                        ],
                    }
                ]
            },
        )
        object_scenario_content = (
            "Scenario 对象字符串 {\n  Interaction 解析成功;\n}\n"
        )
        self.write_dsl(
            dsl_map,
            "ExternalScenarios/对象字符串.dsl",
            object_scenario_content,
        )

        completed = self.run_cli()
        self.assertEqual(0, completed.returncode, completed.stdout)
        payload = self.parse_protocol(completed)

        self.assertEqual("1.0", payload["protocol_version"])
        self.assertEqual("success", payload["status"])
        self.assertIsNone(payload["error"])
        self.assertEqual(5, payload["summary"]["requirement_count"])
        self.assertEqual(6, payload["summary"]["artifact_count"])
        self.assertEqual(6, payload["summary"]["relationship_count"])
        self.assertEqual(1, payload["summary"]["environment_count"])
        self.assertEqual(3, payload["summary"]["external_scenario_count"])
        self.assertEqual(2, payload["summary"]["statechart_count"])
        self.assertEqual(1, payload["summary"]["empty_artifact_requirement_count"])
        self.assertEqual(3, payload["summary"]["metadata_missing_count"])
        self.assertEqual(1, payload["summary"]["orphan_requirement_count"])

        requirements = payload["requirements"]
        self.assertEqual(
            {
                "REQ_LEGACY",
                "REQ_EMPTY",
                "REQ_ORPHAN",
                "REQ_COVERAGE",
                "REQ_OBJECT_STRING",
            },
            set(requirements),
        )
        self.assertEqual(special_name, requirements["REQ_LEGACY"]["name"])
        self.assertEqual(
            special_description,
            requirements["REQ_LEGACY"]["description"],
        )
        self.assertEqual([], requirements["REQ_EMPTY"]["artifacts"])
        self.assertEqual("", requirements["REQ_ORPHAN"]["name"])
        self.assertEqual("", requirements["REQ_ORPHAN"]["description"])
        self.assertEqual(
            [
                {
                    "code": "REQUIREMENT_METADATA_NOT_FOUND",
                    "requirement_id": "REQ_ORPHAN",
                }
            ],
            payload["warnings"],
        )

        artifacts = payload["artifacts"]
        self.assertEqual(
            environment_content,
            artifacts["1旧格式/Environment.dsl"]["content"],
        )
        self.assertEqual(
            "environment",
            artifacts["1旧格式/Environment.dsl"]["type"],
        )
        self.assertEqual(
            legacy_scenario_content,
            artifacts["1旧格式/ExternalScenarios/共享场景.dsl"]["content"],
        )
        for requirement in requirements.values():
            for artifact_id in requirement["artifacts"]:
                self.assertIn(artifact_id, artifacts)

    def test_shared_dsl_is_stored_once_and_linked_twice(self):
        feature = self.create_feature(
            "共享",
            [
                {
                    "requirement_id": "REQ_A",
                    "name": "需求A",
                    "description": "描述A",
                },
                {
                    "requirement_id": "REQ_B",
                    "name": "需求B",
                    "description": "描述B",
                },
            ],
            {
                "coverage": [
                    {
                        "requirement_id": "REQ_A",
                        "artifacts": ["Environment.dsl#Interaction A"],
                    },
                    {
                        "requirement_id": "REQ_B",
                        "artifacts": ["Environment.dsl#Interaction B"],
                    },
                ]
            },
        )
        content = "Environment {\n  Machine 共享模块;\n}\n"
        self.write_dsl(feature, "Environment.dsl", content)

        completed = self.run_cli()
        self.assertEqual(0, completed.returncode)
        payload = self.parse_protocol(completed)
        self.assertEqual(1, payload["summary"]["artifact_count"])
        self.assertEqual(2, payload["summary"]["relationship_count"])
        self.assertEqual(
            ["共享/Environment.dsl"],
            payload["requirements"]["REQ_A"]["artifacts"],
        )
        self.assertEqual(
            ["共享/Environment.dsl"],
            payload["requirements"]["REQ_B"]["artifacts"],
        )
        self.assertEqual(
            content,
            payload["artifacts"]["共享/Environment.dsl"]["content"],
        )

    def test_duplicate_requirement_id_across_directories_is_fatal(self):
        for feature_name in ("A", "B"):
            feature = self.create_feature(
                feature_name,
                [{"requirement_id": "REQ_DUP"}],
                {
                    "coverage": [
                        {
                            "requirement_id": "REQ_DUP",
                            "artifacts": ["Environment.dsl"],
                        }
                    ]
                },
            )
            self.write_dsl(feature, "Environment.dsl", "Environment { }\n")

        self.assert_protocol_error(
            self.run_cli(),
            "DUPLICATE_REQUIREMENT_ID",
        )

    def test_non_string_requirement_metadata_is_fatal(self):
        feature = self.create_feature(
            "非法元数据",
            [{"requirement_id": "REQ_BAD", "name": ["不是字符串"]}],
            {
                "coverage": [
                    {
                        "requirement_id": "REQ_BAD",
                        "artifacts": ["Environment.dsl"],
                    }
                ]
            },
        )
        self.write_dsl(feature, "Environment.dsl", "Environment { }\n")

        self.assert_protocol_error(
            self.run_cli(),
            "INVALID_REQUIREMENT_METADATA",
        )

    def test_path_traversal_is_fatal(self):
        self.create_feature(
            "越界",
            [{"requirement_id": "REQ_ESCAPE"}],
            {
                "coverage": [
                    {
                        "requirement_id": "REQ_ESCAPE",
                        "artifacts": ["../Statecharts/越界.dsl"],
                    }
                ]
            },
        )
        self.assert_protocol_error(
            self.run_cli(),
            "ARTIFACT_PATH_OUTSIDE_FEATURE",
        )

    def test_missing_mapped_dsl_is_fatal(self):
        self.create_feature(
            "缺失",
            [{"requirement_id": "REQ_MISSING"}],
            {
                "coverage": [
                    {
                        "requirement_id": "REQ_MISSING",
                        "artifacts": ["Statecharts/不存在.dsl"],
                    }
                ]
            },
        )
        self.assert_protocol_error(self.run_cli(), "DSL_NOT_FOUND")

    def test_missing_requirements_json_is_fatal(self):
        feature = self.project_root / "缺少需求"
        feature.mkdir()
        self.write_json(feature / "requirement_dsl_map.json", {"coverage": []})
        self.assert_protocol_error(
            self.run_cli(),
            "REQUIREMENTS_NOT_FOUND",
        )

    def test_relative_project_root_is_invalid(self):
        self.assert_protocol_error(
            self.run_cli(Path("relative-project")),
            "INVALID_INPUT",
        )

    def test_nested_map_is_not_discovered(self):
        nested = self.project_root / "outer" / "inner"
        nested.mkdir(parents=True)
        self.write_json(nested / "requirements.json", {"requirements": []})
        self.write_json(nested / "requirement_dsl_map.json", {"coverage": []})
        self.assert_protocol_error(
            self.run_cli(),
            "DSL_MAP_NOT_FOUND",
        )

    def test_skill_contract_keeps_json_out_of_final_answer(self):
        skill_text = (SKILL_ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("不得复制到最终 assistant text", skill_text)
        self.assertIn("最终 assistant text 只显示", skill_text)
        self.assertIn("查询失败：错误 1 项。", skill_text)
        self.assertIn("requirement_count", skill_text)
        self.assertIn("metadata_missing_count", skill_text)


if __name__ == "__main__":
    unittest.main()
