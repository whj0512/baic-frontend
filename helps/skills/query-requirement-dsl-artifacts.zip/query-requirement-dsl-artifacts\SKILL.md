---
name: query-requirement-dsl-artifacts
description: 按 requirement_id 只读查询流水线二场景 3 已生成的 Environment、ExternalScenario 和 Statechart DSL。用于用户提供项目根目录并要求从各功能目录的 requirement_dsl_map.json 与 requirements.json 返回可供前端直接读取的结构化工具结果，同时让最终 Agent 回答只显示统计信息；始终排除 DialogMap。
---

# 按需求查询 DSL 产物

只读查询现有流水线产物。不得运行生成流水线，不得创建、修改、修复或覆盖项目中的
JSON、Markdown 或 DSL 文件。

## 输入契约

必须取得用户明确提供的 `project_root` 绝对路径。不得根据当前工作目录猜测项目根目录，
不得递归搜索嵌套项目。

项目根目录的每个直接子目录只在存在 `requirement_dsl_map.json` 时参与查询，并且该目录
必须同时存在 `requirements.json`。

## 执行流程

1. 定位当前 Skill 目录。
2. 执行：

   ```text
   python scripts/query_requirement_dsl_artifacts.py --project-root "<absolute-path>"
   ```

3. 保留脚本标准输出作为工具调用结果。该结果供前端读取，不得复制到最终 assistant text。
4. 解析工具结果的 `status` 和 `summary`。
5. 无论工具结果是否已自动显示，都必须再发送一条独立的最终 assistant text 消息。

## 工具结果契约

脚本标准输出必须且只能是一个 UTF-8 JSON 对象，不得包含 Markdown、代码围栏、日志或解释。

成功结果稳定包含：

- `protocol_version`
- `status`
- `summary`
- `requirements`
- `artifacts`
- `warnings`
- `error`

`requirements` 以 `requirement_id` 为键，每项只包含 `name`、`description` 和
`artifacts` 引用数组。`artifacts` 以规范化项目相对路径为键，每项只包含 `type` 和完整
`content`。同一 DSL 文件只在 `artifacts` 中保存一次。

`name`、`description` 只来自同目录 `requirements.json`。缺失、`null` 或空字符串时使用
空字符串；不得用 `source_text` 回填或自动生成。

只允许三种 DSL 类型：

- `environment`
- `external-scenario`
- `statechart`

排除所有 DialogMap。只含 DialogMap 的 requirement 仍保留，但其 `artifacts` 数组为空。

失败结果使用同一顶层结构，`status=error`、`summary=null`、两个数据对象为空，并在
`error` 中提供错误码和说明。不得返回部分 DSL 数据。

## 最终回答契约

最终 assistant text 只显示 `summary` 中的统计值，默认使用：

| 需求数 | DSL数 | 映射数 | Environment | ExternalScenario | Statechart | 无产物需求 | 元数据缺失 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| `<requirement_count>` | `<artifact_count>` | `<relationship_count>` | `<environment_count>` | `<external_scenario_count>` | `<statechart_count>` | `<empty_artifact_requirement_count>` | `<metadata_missing_count>` |

最终回答不得包含：

- JSON 或 JSON 片段；
- requirement_id、name、description 明细；
- DSL 路径、DSL 代码或代码围栏；
- warning 或 error 对象；
- “完整结果如下”等引导文字。

当 `status=error` 时，最终回答固定为：

```text
查询失败：错误 1 项。
```

具体错误仅由前端从工具结果读取。

## 安全边界

- 只读取项目根目录的直接功能子目录。
- 兼容 `requirement_dsl_map`、`coverage`、`dsl_map` 和
  `orphan_dsl_references` 映射结构。
- 兼容普通 DSL 路径、`::`/`#` 元素后缀、带 `file` 的结构化对象和
  PowerShell 对象字符串。
- 只接受功能目录内部的 `Environment.dsl`、`ExternalScenarios/*.dsl` 和
  `Statecharts/*.dsl`。
- 拒绝绝对 artifact 路径、路径越界、重复 requirement_id、未知映射结构、
  非字符串 name/description、缺失或不可读 DSL。
