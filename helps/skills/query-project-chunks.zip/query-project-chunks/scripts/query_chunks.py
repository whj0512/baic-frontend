#!/usr/bin/env python3
"""Read a project's direct-child chunks.json and emit the chunks protocol."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path
from typing import Any, Sequence


PROTOCOL_VERSION = "1.0"
DETAIL_CHOICES = ("summary", "full")

EXIT_SUCCESS = 0
EXIT_INPUT_OR_PATH = 2
EXIT_READ_OR_JSON = 3
EXIT_SCHEMA = 4


def configure_stdout() -> None:
    reconfigure = getattr(sys.stdout, "reconfigure", None)
    if reconfigure is not None:
        reconfigure(encoding="utf-8", errors="strict")


class ProtocolArgumentParser(argparse.ArgumentParser):
    """Raise argument errors so they can be returned through the protocol."""

    def error(self, message: str) -> None:
        raise ValueError(message)


def build_parser() -> argparse.ArgumentParser:
    parser = ProtocolArgumentParser(
        description=(
            "Read <project-root>/chunks.json and print exactly one Markdown "
            "chunks fenced block."
        )
    )
    parser.add_argument("--project-root", required=True)
    parser.add_argument(
        "--detail",
        choices=DETAIL_CHOICES,
        default="summary",
    )
    return parser


def render_envelope(
    *,
    status: str,
    project_root: str,
    source_file: str,
    detail: str,
    data: Any,
    warnings: list[str],
    error: dict[str, str] | None,
) -> str:
    envelope = {
        "protocol_version": PROTOCOL_VERSION,
        "status": status,
        "project_root": project_root,
        "source_file": source_file,
        "detail": detail,
        "data": data,
        "warnings": warnings,
        "error": error,
    }
    payload = json.dumps(envelope, ensure_ascii=False, indent=2)
    return f"```chunks\n{payload}\n```"


def emit_error(
    code: str,
    message: str,
    *,
    project_root: str = "",
    source_file: str = "",
    detail: str = "summary",
    warnings: list[str] | None = None,
    exit_code: int,
) -> int:
    output = render_envelope(
        status="error",
        project_root=project_root,
        source_file=source_file,
        detail=detail,
        data=None,
        warnings=warnings or [],
        error={"code": code, "message": message},
    )
    sys.stdout.write(output + "\n")
    return exit_code


def validate_chunks_schema(data: Any) -> tuple[list[str], str | None]:
    if not isinstance(data, dict):
        return [], "chunks.json 根节点必须是 JSON 对象"

    if not isinstance(data.get("document_info"), dict):
        return [], "document_info 必须存在且为 JSON 对象"

    if not isinstance(data.get("chunking_summary"), dict):
        return [], "chunking_summary 必须存在且为 JSON 对象"

    chunks = data.get("chunks")
    if not isinstance(chunks, list):
        return [], "chunks 必须存在且为 JSON 数组"

    seen_ids: set[str] = set()
    warnings: list[str] = []

    for index, chunk in enumerate(chunks):
        if not isinstance(chunk, dict):
            return warnings, f"chunks[{index}] 必须是 JSON 对象"

        chunk_id = chunk.get("chunk_id")
        if not isinstance(chunk_id, str) or not chunk_id.strip():
            return warnings, f"chunks[{index}].chunk_id 必须是非空字符串"
        if chunk_id in seen_ids:
            return warnings, f"chunk_id 重复: {chunk_id}"
        seen_ids.add(chunk_id)

        for field in ("title", "chunk_type", "physical_segments", "source_sections"):
            if field not in chunk:
                warnings.append(f"{chunk_id}: 缺少扩展字段 {field}")

        if chunk.get("chunk_type") == "functional_requirement":
            for field in (
                "canonical_function_name",
                "parent_requirement",
                "requirement_path",
                "hierarchy_evidence",
            ):
                if field not in chunk:
                    warnings.append(f"{chunk_id}: 缺少功能需求扩展字段 {field}")

    if not isinstance(data.get("project_relation_seed"), dict):
        warnings.append("缺少或无效的扩展字段 project_relation_seed")

    return warnings, None


def project_data(data: dict[str, Any], detail: str) -> dict[str, Any]:
    if detail == "full":
        return data

    projected = copy.deepcopy(data)
    for chunk in projected["chunks"]:
        chunk.pop("content", None)
    return projected


def run(argv: Sequence[str] | None = None) -> int:
    configure_stdout()
    parser = build_parser()
    requested_detail = "summary"
    raw_project_root = ""

    try:
        args = parser.parse_args(argv)
        requested_detail = args.detail
        raw_project_root = args.project_root
    except ValueError as exc:
        return emit_error(
            "INVALID_INPUT",
            f"参数无效: {exc}",
            project_root=raw_project_root,
            detail=requested_detail,
            exit_code=EXIT_INPUT_OR_PATH,
        )

    try:
        candidate = Path(raw_project_root).expanduser()
    except (TypeError, ValueError, OSError) as exc:
        return emit_error(
            "INVALID_INPUT",
            f"项目根目录路径无效: {exc}",
            project_root=raw_project_root,
            detail=requested_detail,
            exit_code=EXIT_INPUT_OR_PATH,
        )

    if not candidate.is_absolute():
        return emit_error(
            "INVALID_INPUT",
            "project_root 必须是绝对路径",
            project_root=str(candidate),
            detail=requested_detail,
            exit_code=EXIT_INPUT_OR_PATH,
        )

    try:
        root = candidate.resolve(strict=False)
    except OSError as exc:
        return emit_error(
            "INVALID_INPUT",
            f"无法规范化项目根目录: {exc}",
            project_root=str(candidate),
            detail=requested_detail,
            exit_code=EXIT_INPUT_OR_PATH,
        )

    source = root / "chunks.json"
    root_text = str(root)
    source_text = str(source)

    if not root.exists():
        return emit_error(
            "ROOT_NOT_FOUND",
            "项目根目录不存在",
            project_root=root_text,
            source_file=source_text,
            detail=requested_detail,
            exit_code=EXIT_INPUT_OR_PATH,
        )

    if not root.is_dir():
        return emit_error(
            "ROOT_NOT_DIRECTORY",
            "project_root 不是目录",
            project_root=root_text,
            source_file=source_text,
            detail=requested_detail,
            exit_code=EXIT_INPUT_OR_PATH,
        )

    if not source.exists():
        return emit_error(
            "CHUNKS_NOT_FOUND",
            "项目根目录下不存在 chunks.json",
            project_root=root_text,
            source_file=source_text,
            detail=requested_detail,
            exit_code=EXIT_INPUT_OR_PATH,
        )

    if not source.is_file():
        return emit_error(
            "CHUNKS_READ_FAILED",
            "chunks.json 不是普通文件",
            project_root=root_text,
            source_file=source_text,
            detail=requested_detail,
            exit_code=EXIT_READ_OR_JSON,
        )

    try:
        raw_json = source.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        return emit_error(
            "CHUNKS_READ_FAILED",
            f"无法读取 chunks.json: {exc}",
            project_root=root_text,
            source_file=source_text,
            detail=requested_detail,
            exit_code=EXIT_READ_OR_JSON,
        )

    try:
        data = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        return emit_error(
            "INVALID_JSON",
            f"chunks.json 不是合法 JSON（第 {exc.lineno} 行，第 {exc.colno} 列）",
            project_root=root_text,
            source_file=source_text,
            detail=requested_detail,
            exit_code=EXIT_READ_OR_JSON,
        )

    warnings, schema_error = validate_chunks_schema(data)
    if schema_error:
        return emit_error(
            "INVALID_CHUNKS_SCHEMA",
            schema_error,
            project_root=root_text,
            source_file=source_text,
            detail=requested_detail,
            warnings=warnings,
            exit_code=EXIT_SCHEMA,
        )

    output = render_envelope(
        status="success",
        project_root=root_text,
        source_file=source_text,
        detail=requested_detail,
        data=project_data(data, requested_detail),
        warnings=warnings,
        error=None,
    )
    sys.stdout.write(output + "\n")
    return EXIT_SUCCESS


def main() -> None:
    raise SystemExit(run())


if __name__ == "__main__":
    main()
