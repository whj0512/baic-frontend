import codecs
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = SKILL_ROOT / "scripts" / "query_chunks.py"
FIXTURES = Path(__file__).resolve().parent / "fixtures"


class QueryChunksTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(
            prefix="query-project-chunks-test-",
            dir=SKILL_ROOT.parent,
        )
        self.addCleanup(self.temp_dir.cleanup)
        self.root = Path(self.temp_dir.name)

    def create_project(self, name="project", fixture="valid_chunks.json"):
        project = self.root / name
        project.mkdir()
        shutil.copyfile(FIXTURES / fixture, project / "chunks.json")
        return project

    def run_cli(self, project_root, detail=None, extra_args=None):
        command = [
            sys.executable,
            str(SCRIPT),
            "--project-root",
            str(project_root),
        ]
        if detail is not None:
            command.extend(["--detail", detail])
        if extra_args:
            command.extend(extra_args)
        return subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            check=False,
        )

    def parse_protocol(self, completed):
        self.assertEqual("", completed.stderr)
        self.assertTrue(completed.stdout.startswith("```chunks\n"))
        self.assertTrue(completed.stdout.endswith("\n```\n"))
        self.assertEqual(1, completed.stdout.count("```chunks\n"))
        payload = completed.stdout[len("```chunks\n") : -len("\n```\n")]
        return json.loads(payload)

    def test_summary_is_default_and_removes_only_chunk_content(self):
        project = self.create_project()
        source_data = json.loads((project / "chunks.json").read_text(encoding="utf-8"))

        completed = self.run_cli(project)
        envelope = self.parse_protocol(completed)

        self.assertEqual(0, completed.returncode)
        self.assertEqual("success", envelope["status"])
        self.assertEqual("summary", envelope["detail"])
        self.assertIsNone(envelope["error"])
        self.assertEqual([], envelope["warnings"])
        self.assertEqual(source_data.keys(), envelope["data"].keys())
        self.assertTrue(
            all("content" not in chunk for chunk in envelope["data"]["chunks"])
        )
        self.assertEqual(
            source_data["chunks"][1]["hierarchy_evidence"],
            envelope["data"]["chunks"][1]["hierarchy_evidence"],
        )

    def test_full_preserves_parsed_source_data(self):
        project = self.create_project()
        source_data = json.loads((project / "chunks.json").read_text(encoding="utf-8"))

        completed = self.run_cli(project, detail="full")
        envelope = self.parse_protocol(completed)

        self.assertEqual(0, completed.returncode)
        self.assertEqual("full", envelope["detail"])
        self.assertEqual(source_data, envelope["data"])

    def test_utf8_bom_and_chinese_path(self):
        project = self.root / "中文项目"
        project.mkdir()
        fixture_bytes = (FIXTURES / "valid_chunks.json").read_bytes()
        (project / "chunks.json").write_bytes(codecs.BOM_UTF8 + fixture_bytes)

        completed = self.run_cli(project)
        envelope = self.parse_protocol(completed)

        self.assertEqual(0, completed.returncode)
        self.assertEqual("success", envelope["status"])
        self.assertIn("中文项目", envelope["project_root"])

    def test_nested_chunks_is_not_selected(self):
        project = self.root / "project"
        nested = project / "nested"
        nested.mkdir(parents=True)
        shutil.copyfile(FIXTURES / "valid_chunks.json", nested / "chunks.json")

        completed = self.run_cli(project)
        envelope = self.parse_protocol(completed)

        self.assertEqual(2, completed.returncode)
        self.assertEqual("CHUNKS_NOT_FOUND", envelope["error"]["code"])
        self.assertIsNone(envelope["data"])

    def test_missing_root(self):
        completed = self.run_cli(self.root / "missing")
        envelope = self.parse_protocol(completed)

        self.assertEqual(2, completed.returncode)
        self.assertEqual("ROOT_NOT_FOUND", envelope["error"]["code"])

    def test_root_is_not_directory(self):
        root_file = self.root / "not-a-directory"
        root_file.write_text("x", encoding="utf-8")

        completed = self.run_cli(root_file)
        envelope = self.parse_protocol(completed)

        self.assertEqual(2, completed.returncode)
        self.assertEqual("ROOT_NOT_DIRECTORY", envelope["error"]["code"])

    def test_invalid_json(self):
        project = self.root / "project"
        project.mkdir()
        (project / "chunks.json").write_text('{"chunks":', encoding="utf-8")

        completed = self.run_cli(project)
        envelope = self.parse_protocol(completed)

        self.assertEqual(3, completed.returncode)
        self.assertEqual("INVALID_JSON", envelope["error"]["code"])

    def test_missing_required_schema_field(self):
        project = self.create_project(fixture="invalid_chunks.json")

        completed = self.run_cli(project)
        envelope = self.parse_protocol(completed)

        self.assertEqual(4, completed.returncode)
        self.assertEqual("INVALID_CHUNKS_SCHEMA", envelope["error"]["code"])

    def test_duplicate_chunk_id(self):
        project = self.create_project()
        path = project / "chunks.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        data["chunks"][1]["chunk_id"] = "chunk_001"
        path.write_text(
            json.dumps(data, ensure_ascii=False),
            encoding="utf-8",
        )

        completed = self.run_cli(project)
        envelope = self.parse_protocol(completed)

        self.assertEqual(4, completed.returncode)
        self.assertEqual("INVALID_CHUNKS_SCHEMA", envelope["error"]["code"])

    def test_relative_root_is_invalid_input(self):
        completed = self.run_cli(Path("relative-project"))
        envelope = self.parse_protocol(completed)

        self.assertEqual(2, completed.returncode)
        self.assertEqual("INVALID_INPUT", envelope["error"]["code"])

    def test_invalid_detail_is_protocol_error(self):
        project = self.create_project()

        completed = self.run_cli(project, detail="other")
        envelope = self.parse_protocol(completed)

        self.assertEqual(2, completed.returncode)
        self.assertEqual("INVALID_INPUT", envelope["error"]["code"])


if __name__ == "__main__":
    unittest.main()
