---
name: query-project-chunks
description: 从用户明确指定的项目根目录读取流水线一产出的 chunks.json，并通过确定性的 Markdown chunks 协议将结果写入最终 assistant text 消息。用于查询、检查、列出、渲染或获取 requirement_itemizer 项目中的需求分块、分块元数据或 project_relation_seed。
---

# 查询项目分块

只读查询流水线一已有的 `chunks.json`，不得修改项目。

## 输入契约

必须提供：

- `project_root`：项目根目录的绝对路径。

可以提供：

- `detail=summary`（默认）：保留完整 JSON 结构，但删除每个
  `chunks[*].content` 字段。
- `detail=full`：返回解析后的完整 `chunks.json`。

不得根据当前工作目录推断项目根目录。不得递归搜索。只能读取
`<project_root>/chunks.json`。

## 执行流程

1. 从用户请求中提取项目根目录绝对路径和可选的详细度模式。
2. 定位当前 skill 的目录并执行：

   ```text
   python scripts/query_chunks.py --project-root "<absolute-path>" --detail <summary|full>
   ```

3. 将工具调用及其结果仅视为中间执行步骤。捕获脚本的标准输出；不得把工具结果本身
   当作面向用户的最终答案，也不得在工具调用后直接结束当前轮次。
4. 工具执行完成后，必须再发送一条独立的最终 assistant 消息，消息类型必须为
   `text`。将捕获到的标准输出原样复制到该消息的文本内容中。

最终 assistant text 消息必须且只能包含一个 `chunks` 围栏，包括失败场景。不得只在
工具结果、附件、制品、文件、推理消息或元数据字段中提供该围栏。捕获到的标准输出
前后不得添加标题、解释、引用、第二个代码块、命令输出标签或任何其他文本。

只有独立的 assistant `text` 消息发送成功后，任务才算完成。如果运行环境会自动展示
工具结果，仍然必须继续发送 assistant `text` 消息；解析器读取的是 assistant 消息，
不是工具事件。

## 输出契约

最终 assistant text 内容中的围栏必须包含严格 JSON，并稳定提供以下顶层字段：

- `protocol_version`：始终为 `"1.0"`。
- `status`：`"success"` 或 `"error"`。
- `project_root`：能够取得时，填写规范化后的项目根目录绝对路径。
- `source_file`：能够取得时，填写项目根目录直接子文件 `chunks.json` 的路径。
- `detail`：请求的详细度模式。
- `data`：成功时填写查询结果；失败时为 `null`。
- `warnings`：非致命契约警告。
- `error`：成功时为 `null`；失败时为包含 `code` 和 `message` 的对象。

固定错误码：

- `INVALID_INPUT`
- `ROOT_NOT_FOUND`
- `ROOT_NOT_DIRECTORY`
- `CHUNKS_NOT_FOUND`
- `CHUNKS_READ_FAILED`
- `INVALID_JSON`
- `INVALID_CHUNKS_SCHEMA`

必须强制校验 `document_info`、`chunking_summary`、`chunks` 数组，以及非空且唯一的
`chunk_id`。流水线扩展字段缺失时，只能写入警告，不得修复或补造。

## 安全边界

- 不得运行 `requirement_itemizer` 或其他生成流水线。
- 不得创建、编辑、规范化或覆盖任何项目文件。
- 项目根目录直接子文件缺失时，不得改选嵌套目录中的 `chunks.json`。
- 不得修复非法 JSON，也不得补填缺失字段。
